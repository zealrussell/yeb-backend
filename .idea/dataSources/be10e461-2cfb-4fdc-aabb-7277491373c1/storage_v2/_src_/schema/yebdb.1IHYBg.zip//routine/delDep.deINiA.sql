create
    definer = root@localhost procedure delDep(IN did int, OUT result int)
BEGIN
END;

