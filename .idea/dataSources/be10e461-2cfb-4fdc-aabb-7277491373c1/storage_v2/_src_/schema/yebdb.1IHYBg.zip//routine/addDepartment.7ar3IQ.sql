create
    definer = root@localhost procedure addDepartment(IN depName varchar(32), IN parentId int, IN enabled tinyint,
                                                     OUT result int, OUT result2 int)
BEGIN
	#Routine body goes here...
DECLARE did int;
DECLARE pDepPath VARCHAR(64);
INSERT INTO t_department SET `name`=depName,parentId=parentId,enabled=enabled;
SELECT row_count() INTO result;
SELECT LAST_INSERT_ID() INTO did;
SET result2=did;
SELECT depPath INTO pDepPath FROM t_department WHERE id=parentId;
UPDATE t_department SET depPath=CONCAT(pDepPath,'.',did) WHERE id=did;
UPDATE t_department SET isParent=TRUE WHERE id=parentId;
END;

