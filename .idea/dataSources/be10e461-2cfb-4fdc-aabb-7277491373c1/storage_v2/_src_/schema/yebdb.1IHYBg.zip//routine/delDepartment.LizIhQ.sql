create
    definer = root@localhost procedure delDepartment(IN did int, OUT result int)
BEGIN

	#Routine body goes here...
DECLARE ecount int;
DECLARE pid int;
DECLARE pcount int;
DECLARE a int;
SELECT count(*) INTO a FROM t_department WHERE id=did AND isParent=FALSE;
IF a=0 THEN SET result=-2;
ELSE
SELECT COUNT(*) INTO ecount FROM t_employee WHERE departmentId=did;
IF ecount>0 THEN SET result=-1;
ELSE
SELECT parentId INTO pid FROM t_department WHERE id=did;
DELETE FROM t_department WHERE id=did AND isParent=FALSE;
SELECT ROW_COUNT() INTO result;
SELECT COUNT(*) INTO pcount FROM t_department WHERE parentId=pid;
IF pcount=0 THEN UPDATE t_department SET isParent=FALSE WHERE id=pid;
END IF;
END IF;
END IF;
END;

