create
    definer = root@localhost procedure GreetWorld()
SELECT CONCAT(@greeting,'world');

