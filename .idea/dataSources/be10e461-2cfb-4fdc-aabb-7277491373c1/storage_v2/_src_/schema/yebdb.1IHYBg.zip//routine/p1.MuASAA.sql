create
    definer = root@localhost procedure p1()
    SET @last_procedure='p1';

