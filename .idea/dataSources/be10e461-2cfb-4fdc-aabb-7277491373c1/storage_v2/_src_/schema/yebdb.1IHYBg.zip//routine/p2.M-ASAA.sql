create
    definer = root@localhost procedure p2()
SELECT CONCAT('last_procedure was',@last_procedure);

